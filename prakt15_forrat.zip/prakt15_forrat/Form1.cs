﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prakt15_forrat
{
    public partial class Form1 : Form
    {   int[] zz;
        int[] zz2;
        Massiv massiv = new Massiv();
        public Form1()
        {
            InitializeComponent();
        }
        bool p = false; 
        public void Proverka(string ss)
        {
            for (int i = 0; i < ss.Length; i++)
            {
                if (!char.IsLetter(ss[i])) p = true;
                if (ss.Length < 0) p = false;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Proverka(textBox3.Text);
            if (p == true)
            {
                StreamWriter sw = File.CreateText("first.txt");
                listBox1.Items.Clear();
                zz = massiv.Create(Convert.ToInt32(textBox3.Text));
                for (int i = 0; i < zz.Length; i++)
                {
                    listBox1.Items.Add(zz[i]);
                    sw.WriteLine(zz[i]);
                }
                sw.Close();
            }
           else { MessageBox.Show("введите число", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int[] o1 = new int[zz.Length];
            int[] o2 = new int[zz.Length];
            Proverka(textBox4.Text);
            if (p == true)
            {
                listBox3.Items.Clear();
                StreamWriter sw = File.CreateText("second.txt");
                zz2 = massiv.Create(Convert.ToInt32(textBox4.Text));
                for (int i = 0; i < zz2.Length; i++)
                {
                    listBox3.Items.Add(zz2[i]);
                    sw.WriteLine(zz2[i]);
                }
                sw.Close();
                if (zz.Length == zz2.Length)
                {
                    StreamWriter swo = File.CreateText("operations.txt");
                    StreamWriter swo1 = File.CreateText("operations1.txt");
                    if (File.Exists("second.txt")&& File.Exists("first.txt")) {
                        listBox4.Items.Add("вычитание:");
                        for (int j = 0; j < zz2.Length; j++)
                        {
                            listBox4.Items.Add(o1[j]);
                            o1[j] = zz[j] - zz2[j];
                            
                            listBox4.Items.Add(massiv.Operation1(zz, zz2));
                            swo.WriteLine(massiv.Operation1(zz, zz2));
                        }
                        swo.Close();
                        listBox4.Items.Add("сложение:");
                        for (int j = 0; j < zz2.Length; j++)
                        {
                            o2[j] = zz[j] + zz2[j];
                            listBox4.Items.Add(o2[j]);
                          /*  listBox4.Items.Add(massiv.Operation2(zz, zz2));*/
                            swo1.WriteLine((o2[j]));
                        }
                        swo1.Close();
                    }                
                    else { MessageBox.Show("файлы не найдены", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }                  
                }
                else { MessageBox.Show("размерность должна быть равна первому массиву", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            else { MessageBox.Show("введите число", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Proverka(textBox1.Text);
            if (p == true)
            {
                StreamWriter sww = File.CreateText("index.txt");
                int n = Convert.ToInt32(textBox1.Text);
                File.OpenText("first.txt");
                
             
                 label3.Text=$"{(massiv.Index(zz,n))}";
                    sww.WriteLine(massiv.Index(zz,n));
                
                sww.Close();
            }
            else { MessageBox.Show("введите число", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Proverka(textBox5.Text);
            if (p == true)
            {
                StreamWriter sw = File.CreateText("fromindex.txt");
                File.OpenText("first.txt");
                int k = Convert.ToInt32(textBox5.Text);
                for (int i = k; i < zz.Length; i++)
                {
                    listBox5.Items.Add(massiv.Index(zz,k));
                    sw.WriteLine(massiv.Index(zz, k));
                }
                sw.Close();
            }
            else { MessageBox.Show("введите число", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Proverka(textBox2.Text);
            if (p == true)
            {
                StreamWriter swb = File.CreateText("multiply.txt");
                int bb = Convert.ToInt32(textBox2.Text);
                for (int i = 0; i < zz.Length; i++)
                {
                    zz[i] = zz[i] * bb;
                    listBox2.Items.Add(massiv.Mult(zz, bb));
                    swb.WriteLine(massiv.Mult(zz,bb));
                }
                swb.Close();
            }
            else { MessageBox.Show("введите число", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
