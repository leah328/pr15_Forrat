﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace prakt15_forrat
{
    class Massiv
    {
        private int size { get; set; }
        Random rnd = new Random();
        public int[] Create(int n)
        {
            size = n;
            int[] mas = new int[n];
            for (int i = 0; i < n; i++)
            {
                mas[i] = rnd.Next(-50,50);
            }
            return mas;
        }
        public int[] Operation1(int[] a, int[] b)
        {
            int n = a.Length;
            int[] mas2 = new int[n];
            for (int i = 0; i < n; i++)
            {
                mas2[i] = a[i] - b[i];
            }
            return mas2;
        }
        public int[] Operation2(int[] a, int[] b)
        {
            int n = a.Length;
            int[] mas3 = new int[n];
            for (int i = 0; i < n; i++)
            {
                mas3[i] = a[i] + b[i];
            }
            return mas3;
        }
        /*public int[] Otindex(int[] a, int k)
        {
            
            int n = a.Length;
            int[] mas4 = new int[n];
            for (int i = k; i < n; i++)
            {
                a[i] = a[i];
            }
            return a;
        }*/
        public int Index(int[] a, int n)
        {
            int rez = a[n];
      
            return rez;
        }
        public int[] Mult(int[] a, int b)
        {
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = a[i]*b;
            }

            return a;
        }
    }
   
}
